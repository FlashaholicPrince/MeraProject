package com.cg.ams.service;

import java.util.ArrayList;
import java.util.HashMap;
import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.exception.*;


public interface AdminService {

	public boolean addAsset(Asset asset) throws AdminException;
	public boolean modifyAsset(Asset asset) throws AdminException;
	public boolean validateAssetId(int assetId) throws AdminException;
	ArrayList<Request> viewRequest() throws AdminException;
	Asset getAssetDetails(int assetId) throws AdminException;
	public boolean acceptRequest(int reqId) throws AdminException;
	public boolean rejectRequest(int reqId) throws AdminException;
	public HashMap<Integer,Request> viewAllRequest() throws AdminException;
	public boolean acceptManagerRequest(int key) throws AdminException;
	public boolean rejectManagerRequest(int key) throws AdminException;
	public boolean validateAdmin(String userid,String pwd,String usertype)throws AdminException;
	public HashMap<Integer, Asset> viewAssets()throws AdminException;
}
