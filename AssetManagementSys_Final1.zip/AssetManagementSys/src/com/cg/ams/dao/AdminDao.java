package com.cg.ams.dao;

import java.util.ArrayList;
import java.util.HashMap;
import com.cg.ams.bean.Request;
import com.cg.ams.bean.Asset;
import com.cg.ams.exception.*;


public interface AdminDao
{

	// Validate  Admin And Add Assets
	public boolean validateAdmin(String userid,String pwd,String usertype)throws AdminException;
	public boolean addAsset(Asset asset) throws AdminException;
	
	
	
	
	HashMap<Integer, Asset> viewAssets() throws AdminException;
	Asset getAssetDetails(int assetId) throws AdminException;
	public boolean modifyAsset(Asset asset) throws AdminException;

	
	
	
	// View Request Methods
	public HashMap<Integer,Request> viewAllRequest() throws AdminException;	
	public boolean acceptManagerRequest(int key) throws AdminException;
	public boolean rejectManagerRequest(int key) throws AdminException;
	
	
}
