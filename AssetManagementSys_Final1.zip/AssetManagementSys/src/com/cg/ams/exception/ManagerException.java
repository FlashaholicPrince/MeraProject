package com.cg.ams.exception;

public class ManagerException extends Exception {

String message;
	
	public ManagerException(String msg)
	{
		message = msg;
	}
	public String getMessage()
	{
		return message;
	}
	
}
