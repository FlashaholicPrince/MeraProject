package com.cg.ams.exception;

public class AdminException extends Exception {

String message;
	
	public AdminException(String msg)
	{
		message = msg;
	}
	public String getMessage()
	{
		return message;
	}
	
}
